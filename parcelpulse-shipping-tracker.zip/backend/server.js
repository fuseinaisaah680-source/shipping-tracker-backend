import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import dotenv from 'dotenv';
import { v4 as uuidv4 } from 'uuid';
import db from './db.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const ADMIN_API_KEY = process.env.ADMIN_API_KEY || 'change-this-in-.env';

app.use(cors({ origin: '*'}));
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

// Helpers
function makeTrackingNumber() {
  const now = new Date();
  const y = now.getFullYear();
  const rand = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `SHIP-${y}-${rand}`;
}

function adminAuth(req, res, next) {
  const key = req.header('x-admin-key') || req.query.key;
  if (!key || key !== ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized: invalid admin key' });
  }
  next();
}

// Create shipment (admin)
app.post('/api/shipments', adminAuth, (req, res) => {
  const {
    sender_name, sender_phone,
    recipient_name, recipient_phone,
    origin, destination, weight_kg, service_level
  } = req.body || {};

  if (!sender_name || !recipient_name) {
    return res.status(400).json({ error: 'sender_name and recipient_name are required' });
  }

  const tracking = makeTrackingNumber();
  const insert = db.prepare(`
    INSERT INTO shipments
      (tracking_number, sender_name, sender_phone, recipient_name, recipient_phone, origin, destination, weight_kg, service_level, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Created')
  `);
  const info = insert.run(tracking, sender_name, sender_phone || null, recipient_name, recipient_phone || null, origin || null, destination || null, weight_kg || null, service_level || null);

  const historyInsert = db.prepare(`INSERT INTO history (shipment_id, status, location, note) VALUES (?, ?, ?, ?)`);
  historyInsert.run(info.lastInsertRowid, 'Created', origin || null, 'Shipment created');

  return res.json({ tracking_number: tracking });
});

// Update shipment status (admin)
app.post('/api/shipments/:tracking/status', adminAuth, (req, res) => {
  const { tracking } = req.params;
  const { status, location, note } = req.body || {};

  if (!status) return res.status(400).json({ error: 'status is required' });

  const get = db.prepare('SELECT * FROM shipments WHERE tracking_number = ?');
  const shipment = get.get(tracking);
  if (!shipment) return res.status(404).json({ error: 'Shipment not found' });

  const upd = db.prepare(`UPDATE shipments SET status = ?, updated_at = datetime('now') WHERE id = ?`);
  upd.run(status, shipment.id);

  const historyInsert = db.prepare(`INSERT INTO history (shipment_id, status, location, note) VALUES (?, ?, ?, ?)`);
  historyInsert.run(shipment.id, status, location || null, note || null);

  return res.json({ ok: true });
});

// List shipments (admin)
app.get('/api/shipments', adminAuth, (req, res) => {
  const rows = db.prepare(`SELECT * FROM shipments ORDER BY created_at DESC LIMIT 200`).all();
  return res.json(rows);
});

// Public tracking
app.get('/api/track/:tracking', (req, res) => {
  const { tracking } = req.params;
  const get = db.prepare('SELECT * FROM shipments WHERE tracking_number = ?');
  const shipment = get.get(tracking);
  if (!shipment) return res.status(404).json({ error: 'Tracking number not found' });

  const hist = db.prepare('SELECT status, location, note, created_at FROM history WHERE shipment_id = ? ORDER BY created_at DESC').all(shipment.id);
  return res.json({
    tracking_number: shipment.tracking_number,
    status: shipment.status,
    origin: shipment.origin,
    destination: shipment.destination,
    weight_kg: shipment.weight_kg,
    service_level: shipment.service_level,
    created_at: shipment.created_at,
    updated_at: shipment.updated_at,
    history: hist
  });
});

app.get('/', (_req, res) => {
  res.json({ ok: true, service: 'shipping-tracker-backend' });
});

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});