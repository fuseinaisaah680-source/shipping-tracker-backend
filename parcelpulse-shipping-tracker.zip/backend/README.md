# Shipping Tracker — Backend

**Stack:** Node.js (Express) + SQLite (better-sqlite3)

## Setup

```bash
cd backend
cp .env.example .env  # set ADMIN_API_KEY
npm install
npm run dev           # or npm start
```

The server runs on `http://localhost:5000` by default.

## Admin Authentication
Send header `x-admin-key: <your ADMIN_API_KEY>` with admin endpoints.

## Endpoints

- `POST /api/shipments` (admin)
  - Body: `{ sender_name, sender_phone?, recipient_name, recipient_phone?, origin?, destination?, weight_kg?, service_level? }`
  - Returns: `{ tracking_number }`

- `POST /api/shipments/:tracking/status` (admin)
  - Body: `{ status, location?, note? }`

- `GET /api/shipments` (admin)
  - Returns list of recent shipments

- `GET /api/track/:tracking` (public)
  - Returns shipment details + history