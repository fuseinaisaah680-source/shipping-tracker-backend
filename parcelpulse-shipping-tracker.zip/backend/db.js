import Database from 'better-sqlite3';

const db = new Database('data.sqlite');

// Initialize schema
db.exec(`
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS shipments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tracking_number TEXT UNIQUE NOT NULL,
    sender_name TEXT NOT NULL,
    sender_phone TEXT,
    recipient_name TEXT NOT NULL,
    recipient_phone TEXT,
    origin TEXT,
    destination TEXT,
    weight_kg REAL,
    service_level TEXT,
    status TEXT NOT NULL DEFAULT 'Created',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_id INTEGER NOT NULL,
    status TEXT NOT NULL,
    location TEXT,
    note TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (shipment_id) REFERENCES shipments(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_shipments_tracking ON shipments(tracking_number);
  CREATE INDEX IF NOT EXISTS idx_history_shipment ON history(shipment_id);
`);

export default db;