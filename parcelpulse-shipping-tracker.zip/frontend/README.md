# Shipping Tracker — Frontend (Next.js)

## Setup
```bash
cd frontend
cp .env.local.example .env.local   # set NEXT_PUBLIC_BACKEND_URL to your backend URL
npm install
npm run dev
```
Open http://localhost:3000

## Pages
- `/` — Public tracking page
- `/admin` — Admin console to create shipments & update status (requires backend admin key)