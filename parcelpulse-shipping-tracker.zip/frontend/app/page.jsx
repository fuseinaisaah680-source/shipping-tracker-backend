'use client';
import { useState } from 'react';

const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || '';

export default function Home() {
  const [tracking, setTracking] = useState('');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  async function handleTrack(e) {
    e.preventDefault();
    setLoading(true);
    setError('');
    setData(null);
    try {
      const res = await fetch(`${BACKEND}/api/track/${encodeURIComponent(tracking)}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to fetch');
      setData(json);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container">
      <div className="card">
        <h1>ParcelPulse</h1>
        <p className="small">Enter your tracking number to see live status & history.</p>
        <form onSubmit={handleTrack}>
          <input className="input" placeholder="e.g. SHIP-2025-ABC123" value={tracking} onChange={(e) => setTracking(e.target.value)} />
          <button className="button">{loading ? 'Tracking...' : 'Track Shipment'}</button>
        </form>
        {error && <p style={{color:'#fca5a5'}}>{error}</p>}
      </div>

      {data && (
        <div className="card" style={{marginTop: 16}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <h2>{data.tracking_number}</h2>
            <span className="badge">{data.status}</span>
          </div>
          <div className="grid">
            <div>
              <h3>Details</h3>
              <p><strong>Service:</strong> {data.service_level || '—'}</p>
              <p><strong>Weight:</strong> {data.weight_kg ? `${data.weight_kg} kg` : '—'}</p>
              <p><strong>Route:</strong> {data.origin || '—'} → {data.destination || '—'}</p>
              <p className="small">Created: {new Date(data.created_at).toLocaleString()}</p>
              <p className="small">Updated: {new Date(data.updated_at).toLocaleString()}</p>
            </div>
            <div>
              <h3>History</h3>
              <ul className="timeline">
                {data.history.map((h, i) => (
                  <li key={i}>
                    <strong>{h.status}</strong> {h.location ? `@ ${h.location}` : ''}
                    {h.note ? ` — ${h.note}` : ''}
                    <div className="small">{new Date(h.created_at).toLocaleString()}</div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <p className="small">Need help? <a href="mailto:support@example.com">Contact support</a></p>
        </div>
      )}

      <div className="card" style={{marginTop:16}}>
        <h3>Admin</h3>
        <p className="small">Go to <a href="/admin">Admin Console</a> to create & update shipments.</p>
      </div>
    </div>
  );
}