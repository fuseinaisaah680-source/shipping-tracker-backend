'use client';
import { useEffect, useState } from 'react';

const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || '';

export default function Admin() {
  const [key, setKey] = useState('');
  const [created, setCreated] = useState('');
  const [err, setErr] = useState('');
  const [list, setList] = useState([]);
  const [form, setForm] = useState({
    sender_name: '',
    sender_phone: '',
    recipient_name: '',
    recipient_phone: '',
    origin: '',
    destination: '',
    weight_kg: '',
    service_level: 'Standard'
  });
  const [update, setUpdate] = useState({ tracking: '', status: 'In Transit', location: '', note: '' });

  useEffect(() => {
    const saved = localStorage.getItem('admin_key');
    if (saved) setKey(saved);
  }, []);

  function saveKey(v) {
    setKey(v);
    localStorage.setItem('admin_key', v);
  }

  async function fetchList() {
    setErr('');
    try {
      const res = await fetch(`${BACKEND}/api/shipments`, { headers: { 'x-admin-key': key }});
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed');
      setList(json);
    } catch (e) { setErr(e.message); }
  }

  async function createShipment(e) {
    e.preventDefault();
    setErr(''); setCreated('');
    try {
      const res = await fetch(`${BACKEND}/api/shipments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': key },
        body: JSON.stringify({ ...form, weight_kg: form.weight_kg ? parseFloat(form.weight_kg) : null })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed');
      setCreated(json.tracking_number);
      setForm({ sender_name:'', sender_phone:'', recipient_name:'', recipient_phone:'', origin:'', destination:'', weight_kg:'', service_level:'Standard' });
      fetchList();
    } catch (e) { setErr(e.message); }
  }

  async function updateStatus(e) {
    e.preventDefault();
    setErr('');
    try {
      const res = await fetch(`${BACKEND}/api/shipments/${encodeURIComponent(update.tracking)}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': key },
        body: JSON.stringify({ status: update.status, location: update.location || undefined, note: update.note || undefined })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed');
      fetchList();
    } catch (e) { setErr(e.message); }
  }

  return (
    <div className="container">
      <div className="card">
        <h1>Admin Console</h1>
        <p className="small">Set your admin API key (from backend <code>.env</code>).</p>
        <input className="input" placeholder="x-admin-key" value={key} onChange={e=>saveKey(e.target.value)} />
        <button className="button" onClick={fetchList}>Load Recent Shipments</button>
        {err && <p style={{color:'#fca5a5'}}>{err}</p>}
      </div>

      <div className="grid" style={{marginTop:16}}>
        <div className="card">
          <h2>Create Shipment</h2>
          <form onSubmit={createShipment}>
            <input className="input" placeholder="Sender name" value={form.sender_name} onChange={e=>setForm({...form, sender_name:e.target.value})} required />
            <input className="input" placeholder="Sender phone" value={form.sender_phone} onChange={e=>setForm({...form, sender_phone:e.target.value})} />
            <input className="input" placeholder="Recipient name" value={form.recipient_name} onChange={e=>setForm({...form, recipient_name:e.target.value})} required />
            <input className="input" placeholder="Recipient phone" value={form.recipient_phone} onChange={e=>setForm({...form, recipient_phone:e.target.value})} />
            <input className="input" placeholder="Origin city" value={form.origin} onChange={e=>setForm({...form, origin:e.target.value})} />
            <input className="input" placeholder="Destination city" value={form.destination} onChange={e=>setForm({...form, destination:e.target.value})} />
            <input className="input" type="number" step="0.01" placeholder="Weight (kg)" value={form.weight_kg} onChange={e=>setForm({...form, weight_kg:e.target.value})} />
            <select className="input" value={form.service_level} onChange={e=>setForm({...form, service_level:e.target.value})}>
              <option>Standard</option>
              <option>Express</option>
              <option>Overnight</option>
              <option>Freight</option>
            </select>
            <button className="button">Create</button>
          </form>
          {created && <p>Created tracking: <strong>{created}</strong></p>}
        </div>

        <div className="card">
          <h2>Update Status</h2>
          <form onSubmit={updateStatus}>
            <input className="input" placeholder="Tracking number" value={update.tracking} onChange={e=>setUpdate({...update, tracking:e.target.value})} required />
            <select className="input" value={update.status} onChange={e=>setUpdate({...update, status:e.target.value})}>
              <option>Created</option>
              <option>Accepted at Origin</option>
              <option>In Transit</option>
              <option>Arrived at Hub</option>
              <option>Out for Delivery</option>
              <option>Delivered</option>
              <option>Exception</option>
              <option>Returned</option>
            </select>
            <input className="input" placeholder="Location (optional)" value={update.location} onChange={e=>setUpdate({...update, location:e.target.value})} />
            <input className="input" placeholder="Note (optional)" value={update.note} onChange={e=>setUpdate({...update, note:e.target.value})} />
            <button className="button">Update</button>
          </form>
        </div>
      </div>

      <div className="card" style={{marginTop:16}}>
        <h2>Recent Shipments</h2>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%', borderCollapse:'collapse'}}>
            <thead>
              <tr>
                <th style={{textAlign:'left', padding:8}}>Tracking</th>
                <th style={{textAlign:'left', padding:8}}>Status</th>
                <th style={{textAlign:'left', padding:8}}>Route</th>
                <th style={{textAlign:'left', padding:8}}>Weight</th>
                <th style={{textAlign:'left', padding:8}}>Created</th>
              </tr>
            </thead>
            <tbody>
              {list.map((s,i)=>(
                <tr key={i} style={{borderTop:'1px solid rgba(255,255,255,0.1)'}}>
                  <td style={{padding:8}}>{s.tracking_number}</td>
                  <td style={{padding:8}}>{s.status}</td>
                  <td style={{padding:8}}>{s.origin || '—'} → {s.destination || '—'}</td>
                  <td style={{padding:8}}>{s.weight_kg || '—'}</td>
                  <td style={{padding:8}}>{new Date(s.created_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}