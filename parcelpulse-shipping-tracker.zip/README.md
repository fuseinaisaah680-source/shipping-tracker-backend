# ParcelPulse — Shipping & Tracking MVP

A lightweight shipping MVP with:
- Public tracking site (Next.js)
- Admin console (create shipments, update status)
- Backend API (Express + SQLite)

## Quick Start (Local)

### 1) Backend
```bash
cd backend
cp .env.example .env         # set ADMIN_API_KEY
npm install
npm run dev                  # runs on http://localhost:5000
```

### 2) Frontend
```bash
cd frontend
cp .env.local.example .env.local
# Set NEXT_PUBLIC_BACKEND_URL=http://localhost:5000
npm install
npm run dev                  # http://localhost:3000
```

## Deploy

### Backend (Render/Railway/Heroku suggested)
- Create a new Node server project.
- Set environment variable `ADMIN_API_KEY` to a strong value.
- Deploy; persistent disk recommended for SQLite.

### Frontend (Vercel/Netlify)
- Set `NEXT_PUBLIC_BACKEND_URL` to your deployed backend URL.
- Build & deploy.

## Security Notes
- Admin endpoints require `x-admin-key` header.
- Use HTTPS in production.
- SQLite is fine for MVP; migrate to PostgreSQL later.

## Extending
- Add driver mobile app for scanning.
- Add webhooks for SMS/Email notifications.
- Integrate maps for live location.